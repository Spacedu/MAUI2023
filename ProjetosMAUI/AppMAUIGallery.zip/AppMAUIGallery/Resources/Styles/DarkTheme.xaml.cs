namespace AppMAUIGallery.Resources.Styles;

public partial class DarkTheme : ResourceDictionary
{
	public DarkTheme()
	{
		InitializeComponent();
	}
}