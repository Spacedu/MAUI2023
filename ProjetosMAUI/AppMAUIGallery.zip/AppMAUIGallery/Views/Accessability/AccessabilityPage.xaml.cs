namespace AppMAUIGallery.Views.Accessability;

public partial class AccessabilityPage : ContentPage
{
	public AccessabilityPage()
	{
		InitializeComponent();
	}
}