namespace AppMAUIGallery.Views.Cells;

public partial class ImageCellPage : ContentPage
{
	public ImageCellPage()
	{
		InitializeComponent();
	}
}