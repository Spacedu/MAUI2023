namespace AppMAUIGallery.Views.Cells;

public partial class SwitchCellPage : ContentPage
{
	public SwitchCellPage()
	{
		InitializeComponent();
	}
}