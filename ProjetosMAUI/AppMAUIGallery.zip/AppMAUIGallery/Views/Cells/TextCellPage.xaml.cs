namespace AppMAUIGallery.Views.Cells;

public partial class TextCellPage : ContentPage
{
	public TextCellPage()
	{
		InitializeComponent();
	}
}