namespace AppMAUIGallery.Views.CommunityMaui;

public partial class ExpanderPage : ContentPage
{
	public ExpanderPage()
	{
		InitializeComponent();
	}
}