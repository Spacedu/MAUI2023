namespace AppMAUIGallery.Views.Components.Mains;

public partial class ImagePage : ContentPage
{
	public ImagePage()
	{
		InitializeComponent();
        /*
		Imagem01.Source pode ter 4 valores:
		- ImageSource.FromFile
		- ImageSource.FromResource
		- ImageSource.FromStream
		- ImageSource.FromUri
		*/
    }
}