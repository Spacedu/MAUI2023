namespace AppMAUIGallery.Views.Components.Mains;

public partial class LabelPage : ContentPage
{
	public LabelPage()
	{
		InitializeComponent();
	}
}