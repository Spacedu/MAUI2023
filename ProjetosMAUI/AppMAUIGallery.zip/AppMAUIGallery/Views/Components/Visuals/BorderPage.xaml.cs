namespace AppMAUIGallery.Views.Components.Visuals;

public partial class BorderPage : ContentPage
{
	public BorderPage()
	{
		InitializeComponent();
	}
}