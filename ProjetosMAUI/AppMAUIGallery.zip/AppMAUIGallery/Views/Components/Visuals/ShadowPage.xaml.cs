namespace AppMAUIGallery.Views.Components.Visuals;

public partial class ShadowPage : ContentPage
{
	public ShadowPage()
	{
		InitializeComponent();
	}
}