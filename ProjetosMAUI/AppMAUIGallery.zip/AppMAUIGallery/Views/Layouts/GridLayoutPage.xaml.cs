namespace AppMAUIGallery.Views.Layouts;

public partial class GridLayoutPage : ContentPage
{
	public GridLayoutPage()
	{
		InitializeComponent();
	}
}