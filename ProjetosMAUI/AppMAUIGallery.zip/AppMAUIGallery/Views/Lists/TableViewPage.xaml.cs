namespace AppMAUIGallery.Views.Lists;

public partial class TableViewPage : ContentPage
{
	public TableViewPage()
	{
		InitializeComponent();
	}
}