namespace AppMAUIGallery.Views.Shells.Pages;

public partial class Page03 : ContentPage
{
	public Page03()
	{
		InitializeComponent();
	}
}