namespace AppMAUIGallery.Views.Shells.Pages;

public partial class Page05 : ContentPage
{
	public Page05()
	{
		InitializeComponent();
	}
}