namespace AppMAUIGallery.Views.Styles;

public partial class InheirtanceStyle : ContentPage
{
	public InheirtanceStyle()
	{
		InitializeComponent();
	}
}