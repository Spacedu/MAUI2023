﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppMAUIGallery.Views.Styles.MyControls
{
    public class MyLabel : Label
    {
        public MyLabel()
        {
            FontAttributes = FontAttributes.Bold;
        }
    }
}
