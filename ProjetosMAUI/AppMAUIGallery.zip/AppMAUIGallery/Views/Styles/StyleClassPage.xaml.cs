namespace AppMAUIGallery.Views.Styles;

public partial class StyleClassPage : ContentPage
{
	public StyleClassPage()
	{
		InitializeComponent();
	}
}