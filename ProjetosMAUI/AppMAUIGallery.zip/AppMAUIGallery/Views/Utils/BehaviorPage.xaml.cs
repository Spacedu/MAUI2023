namespace AppMAUIGallery.Views.Utils;

public partial class BehaviorPage : ContentPage
{
	public BehaviorPage()
	{
		InitializeComponent();
	}
}